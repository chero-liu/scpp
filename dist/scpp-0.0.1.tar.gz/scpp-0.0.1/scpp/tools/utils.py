import importlib
import os
from scpp.__init__ import ROOT_PATH


def get_assay_text(assay):
    """
    add sinlge cell prefix
    """
    return 'Single-cell ' + assay

def find_assay_init(assay):
    init_module = importlib.import_module(f"scpp.{assay}.__init__")
    return init_module



def find_step_module(assay, step):
    file_path_dict = {
        'assay': f'{ROOT_PATH}/{assay}/{step}.py',
        'tools': f'{ROOT_PATH}/tools/{step}.py',
    }

    init_module = find_assay_init(assay)

    
    if os.path.exists(file_path_dict['assay']):
        step_module = importlib.import_module(f"scpp.{assay}.{step}")
    elif hasattr(init_module, 'IMPORT_DICT') and step in init_module.IMPORT_DICT:
        module_path = init_module.IMPORT_DICT[step]
        step_module = importlib.import_module(f"{module_path}.{step}")
    elif os.path.exists(file_path_dict['tools']):
        step_module = importlib.import_module(f"scpp.tools.{step}")
    else:
        raise ModuleNotFoundError(f"No module found for {assay}.{step}")

    return step_module