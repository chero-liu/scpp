import os

__VERSION__ = "0.0.1"

ASSAY_LIST = [
    'integration'
]

ROOT_PATH = os.path.dirname(__file__)

RELEASED_ASSAYS = ['integration']
