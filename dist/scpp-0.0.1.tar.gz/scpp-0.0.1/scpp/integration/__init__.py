__STEPS__ = [
    'merge'
    ]
__ASSAY__ = 'integration'