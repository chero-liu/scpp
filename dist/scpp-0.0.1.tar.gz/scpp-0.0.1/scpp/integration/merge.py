from scpp.tools.utils import s_common, Step
from scpp.tools.read.create import Create
from scpp.tools.cluster import Cluster
from scpp.tools.rankgenes import RankGenes
from scpp.tools.plot import Plot
from scpp.tools.logger import logging
from scpp.plotting.color_map import colormap, setcolor, addcolor
from scpp.tools.read.create import aws_cp
import unittest


class Merge(Step):

    def __init__(self, args):

        Step.__init__(self, args)
        self.info = args.info
        self.extra_info = args.extra_info
        self.mtfilter = args.mtfilter
        self.hvg_list = args.hvg_list
        self.hvg_num = args.hvg_num

        self.rmoutlier = args.rmoutlier
        self.rmdoublet = args.rmdoublet
        self.rmcontamination = args.rmcontamination

        self.mingene = args.mingene
        self.minumi = args.minumi
        self.maxgene = args.maxgene
        self.maxumi = args.maxumi
        self.mincell = args.mincell

        self.max_cell = args.max_cell
        self.flavor = args.flavor
        self.n_pcs = args.n_pcs
        self.batch_method = args.batch_method
        self.batch_name = args.batch_name
        self.clust_method = args.clust_method
        self.min_dist = args.min_dist
        self.regress_phase = args.regress_phase
        self.regress_mt = args.regress_mt
        self.resolution = args.resolution

        self.method = args.method
        self.cal_logfc = args.cal_logfc
        self.logfc = args.logfc
        self.minpct = args.minpct
        self.diff_anno = args.diff_anno
        self.organ = args.organ
        self.anno_type = args.anno_type
        self.subset = args.subset

        self.DoubletRatio = args.DoubletRatio
        self.legend_fontsize = args.legend_fontsize
        self.gname_slot = args.gname_slot
        self.colors = args.colors
        self.dpi = args.dpi
        self.groupby = "raw_cluster"

    def create(self):

        create_obj = Create(info=self.info,
                            extra_info=self.extra_info,
                            outdir=self.outdir,
                            prefix=self.prefix,
                            species=self.species,
                            mtfilter=self.mtfilter,
                            rmoutlier=self.rmoutlier,
                            rmdoublet=self.rmdoublet,
                            rmcontamination=self.rmcontamination,
                            mingene=self.mingene,
                            minumi=self.minumi,
                            maxumi=self.maxumi,
                            maxgene=self.maxgene,
                            mincell=self.mincell)
        adata = create_obj.run()

        return adata

    def cluster(self, adata):

        cluster_obj = Cluster(adata=adata,
                              outdir=self.outdir,
                              prefix=self.prefix,
                              species=self.species,
                              max_cell=self.max_cell,
                              flavor=self.flavor,
                              n_pcs=self.n_pcs,
                              batch_method=self.batch_method,
                              batch_name=self.batch_name,
                              clust_method=self.clust_method,
                              min_dist=self.min_dist,
                              regress_phase=self.regress_phase,
                              regress_mt=self.regress_mt,
                              resolution=self.resolution,
                              hvg_num=self.hvg_num,
                              hvg_list=self.hvg_list)
        adata = cluster_obj.run()

        return adata

    def rankgenes(self, adata):

        rank_obj = RankGenes(adata=adata,
                             outdir=self.outdir,
                             prefix=self.prefix,
                             species=self.species,
                             method=self.method,
                             cal_logfc=self.cal_logfc,
                             logfc=self.logfc,
                             minpct=self.minpct,
                             diff_anno=self.diff_anno,
                             organ=self.organ,
                             anno_type=self.anno_type,
                             subset=self.subset,
                             groupby=self.groupby)
        adata = rank_obj.run()

        return adata
                
    def plot(self, adata):

        plot_obj = Plot(adata=adata,
                        outdir=self.outdir,
                        prefix=self.prefix,
                        groupby=self.groupby,
                        doubletratio=self.DoubletRatio,
                        legend_fontsize=self.legend_fontsize,
                        gname_slot=self.gname_slot,
                        dpi=self.dpi)
        adata = plot_obj.run()
        
        return adata

    def run(self):

        print("Start Merge pipeline ...")
        adata = self.create()

        if self.hvg_list != "None":
            if self.hvg_list.startswith('s3'):
                try:
                    aws_cp(self.hvg_list, "hvg_list.txt")
                    self.hvg_list = "hvg_list.txt"
                except:
                    raise Exception("Sorry, S3 file copy failed.")
            else:
                pass

        adata = self.cluster(adata)
        adata = addcolor(adata, self.colors, self.gname_slot)
        adata = self.plot(adata)
        adata = self.rankgenes(adata)


def merge(args):
    with Merge(args) as runner:
        runner.run()


def get_opts_merge(parser, sub_program=True):
    parser.add_argument('--mtfilter',
                        type=str,
                        default="default",
                        help="if default, automatically choose a mt threshold for all samples. Recommend")
    parser.add_argument('--rmoutlier',
                        type=str,
                        default="False",
                        help="if True, cutoff will not work")
    parser.add_argument('--rmdoublet',
                        type=str,
                        default="False",
                        help="if True, max gene and max umi will not be work")
    parser.add_argument('--rmcontamination',
                        type=str,
                        default="False",
                        help="if auto, will remove contamination. Individual samples can also be specified")
    parser.add_argument('--mingene',
                        type=float,
                        default=200,
                        help="minimum gene content cutoff")
    parser.add_argument('--maxgene',
                        type=float,
                        default=0.98,
                        help="maximum gene content cutoff")
    parser.add_argument('--maxumi',
                        type=float,
                        default=0.98,
                        help="maximum umi content cutoff")
    parser.add_argument('--minumi',
                        type=float,
                        default=0,
                        help="minimum umi content cutoff")
    parser.add_argument('--mincell',
                        type=int,
                        default=5,
                        help="filter genes if exists in less than an exact number of cells")
    parser.add_argument('--max_cell',
                        type=int,
                        default=500000,
                        help="maximum cells cutoff to perform some analysis")
    parser.add_argument('--flavor',
                        type=str,
                        default="default",
                        help="use all genes or hvg")
    parser.add_argument('--n_pcs',
                        type=str,
                        default="default",
                        help="calculate principle components automatically or use an exact pc number")
    parser.add_argument('--batch_method',
                        type=str,
                        default="No",
                        help="whether remove batch, and which method used")
    parser.add_argument('--batch_name',
                        type=str,
                        default="sample",
                        help="if batch_method is not 'No', which column used to remove batch")
    parser.add_argument('--clust_method',
                        type=str,
                        default="louvain",
                        help="cluster method, louvain or leiden")
    parser.add_argument('--min_dist',
                        type=str,
                        default="default",
                        help="a umap argument")
    parser.add_argument('--regress_phase',
                        type=str,
                        default="False",
                        help="whether regress out phase effect")
    parser.add_argument('--regress_mt',
                        type=str,
                        default="False",
                        help="whether regress out mt effect")
    parser.add_argument('--resolution',
                        type=float,
                        default=1.2,
                        help="a parameter value controlling the coarseness of the clustering")
    parser.add_argument('--method',
                        type=str,
                        default='wilcoxon',
                        help='rank genes method.')
    parser.add_argument('--cal_logfc',
                        type=str,
                        default='seurat',
                        help='method to calculate logfc.')
    parser.add_argument('--logfc',
                        type=float,
                        default=0.25,
                        help='logfoldchanges cutoff')
    parser.add_argument('--minpct',
                        type=float,
                        default=0.1,
                        help='min pct cutoff')
    parser.add_argument('--diff_anno',
                        type=str,
                        default='False',
                        help='add gene annotation')
    parser.add_argument('--subset',
                        type=float,
                        default=300,
                        help='specific number or fraction used for sampling')
    parser.add_argument('--anno_type',
                        default="all",
                        help="argument used for match match")
    parser.add_argument('--DoubletRatio',
                        type=float,
                        default=1,
                        help='cutoff ratio to filter doublet')
    parser.add_argument('--legend_fontsize',
                        type=int,
                        default=10,
                        help='legend font size')
    parser.add_argument('--dpi',
                        type=int,
                        default=300,
                        help='image dpi')
    parser.add_argument('--gname_slot',
                        type=str,
                        default='gname',
                        help='group column name in adata.obs')
    parser.add_argument('--hvg_num',
                        type=int,
                        default=2000,
                        help='hvg genes number')

    if sub_program:
        parser = s_common(parser)
        parser.add_argument('--info',
                            help="a project description config file, include rawname, samplename, groupname, etc")
        parser.add_argument('--extra_info',
                            default="None",
                            help="add new group name if needed. ")
        parser.add_argument('--hvg_list',
                            default="None",
                            help="add hvg list if needed. ")

    return parser


if __name__ == '__main__':
    unittest.main()
